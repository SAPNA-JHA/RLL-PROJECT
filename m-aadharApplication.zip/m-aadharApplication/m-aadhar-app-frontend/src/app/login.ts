export class Login {
    constructor(public emailid:string,
        public password:string,
        public typeOfUser:string){}
}
